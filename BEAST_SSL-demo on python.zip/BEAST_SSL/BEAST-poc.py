'''
    BEAST attack on AES - PoC
'''

import random
import binascii
import sys
from Crypto.Cipher import AES
from Crypto import Random


def pad(s):
    return s + (16 - len(s) % 16) * chr(16 - len(s) % 16)


def unpad(s):
    return s[:-ord(s[len(s) - 1:])]


## create a key.
global key
key = Random.new().read(AES.block_size)


# encrypt msg, with or withOut iv
def encrypt(msg, iv_p=0):
    raw = pad(msg)
    if iv_p == 0:
        iv = Random.new().read(AES.block_size)  # actually there is an initial iv and it is not random
    else:
        iv = iv_p

    cipher = AES.new(key, AES.MODE_CBC, iv)
    return cipher.encrypt(raw)


"""
    The PoC of BEAST attack -
    Implementation of the cryptographic path behind the attack
    - the attacker can retrieve the request send be the client 
    - but also make the client send requests with the plain text of his choice
"""


def xor_strings(xs, ys, zs):
    return "".join(chr(ord(x) ^ ord(y) ^ ord(z)) for x, y, z in zip(xs, ys, zs))


def xor_block(vector_init, previous_cipher, p_guess):
    xored = xor_strings(vector_init, previous_cipher, p_guess)
    return xored


def split_len(seq, length):
    return [seq[i:i + length] for i in range(0, len(seq), length)]


# the PoC start here
def BEAST_SSL(find_me):
    print "Start decrypting the request using block 0 --> block 1\n"

    secret = []

    # the part of the request the atacker know, can be null
    i_know = "password: "

    # padding is the length we need to add to i_know to create a length of 15 bytes (block size- 1)
    padding = 16 - len(i_know) - 1
    i_know = "a" * padding + i_know
    length_block = 16
    t = 0

    first_r = encrypt(
        "could be anything...1!!!could be anything. could be anything !!could be anything !!could be anything")
    lastBlockOfFirst = str(first_r[-length_block:])  ## yellow block

    while (t < (len(find_me) - len("password: "))):

        # good pad
        if padding < 0:
            s = find_me[-1 * (padding):]
        else:
            s = find_me

        for i in range(0, 256):

            # we hold the iv
            # the second request is send       first_r IS THE VULNERABILITY
            enc = encrypt("a" * (padding) + s, lastBlockOfFirst)

            # get the value of the request ciphered
            cipherBlocks = split_len(binascii.hexlify(enc), 32)

            # (GUESS)XOR(VI)XOR(C_I_1) build by the attacker
            p_guess = i_know + chr(i)
            vector_init = str(enc[-length_block:])  # purple block
            previous_cipher = lastBlockOfFirst

            xored = xor_block(vector_init, previous_cipher, p_guess)

            # with some javascript injection, you force the client to send the
            # request of your choice, the TLS1.0 fix the IV to the last block of the previous request
            # with a MiTM you intercept the result and get
            enc = encrypt(xored, vector_init)

            result = split_len(binascii.hexlify(enc), 32)

            if (chr(i) > ' '): #i:
                debug =  chr(i)


            sys.stdout.write("\r%s -> %s" % (cipherBlocks[0], result[0]))
            sys.stdout.flush()  # Shows the tests

            # if the result request contains the same cipher block from the original request -> OK
            if result[0] == cipherBlocks[0]:
                print " Find char " + chr(i)
                i_know = p_guess[1:]
                padding = padding - 1
                secret.append(chr(i))
                t = t + 1
                break
            elif i == 255:
                print "Unable to find the char..."
                return secret
    return secret


# the attacker don't know the password
secret = BEAST_SSL("password: 123_UrI@L")

found = ''.join(secret)
print "\n" + found
